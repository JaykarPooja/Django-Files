from django.shortcuts import render

# Create your views here.
def calci(request):
    try:
        num1=int(request.GET.get('First',0))
        num2=int(request.GET.get('Second',0))
        op= request.GET.get('op')
        output = 0
        if  op == "Add":
            output = num1+num2
        elif  op == "Sub":
            output = num1-num2
        elif  op == "Mul":
            output = num1*num2
        elif  op == "Div":
            output = num1/num2

        return render(request, "index.html", {'Result':output})
    except:
        return render(request, "index.html", {'Result':0})
