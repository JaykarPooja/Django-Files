from django.shortcuts import render
from datetime import datetime

# Create your views here.               
def index(request):
    # name="yogesh"
    name=["yogesh","nayna","krishna"]
    return render(request,"index.html",{'name1':name})   # name1 is a key => paasing name variable to html page
    
def about(request):
    student={
        'name': "Yogesh",
        'age': 25,
        'course': 'Fullstack'
    }
    return render(request,"about.html",student)    # student = dictionary paasing to html page

def contact(request):
    dict={
        "s1":{"name":"yogesh malvia" ,"ph":8925457845},
        "s2":{"name":"pooja Yadav" ,"ph":9825654634}
    }
    return render(request,"contact.html",dict)

def sum(request):
    try:
        x=int(request.Get.get('first',0))
        y=int(request.Get.get('second',0))
        z = x+y
        return render(request,"sum.html",{'addition':z})
    except:
        return render(request,"sum.html",{'addition':0})
    
def newfor(request):
    dict=[
    {"name":"yogesh" ,"age":25, "doj":"2024-1-1"},
    {"name":"pooja" ,"age":20, "doj":"2020-8-12"},  
    {"name":"neeta" ,"age":17, "doj":"2015-9-15"},
    {"name":"ritu" ,"age":15, "doj":"2015-9-15","about":"Social media has become an essential part of day-to-day life in this technology-friendly era. Updating a WhatsApp Status gives your contacts a small glimpse into your life. However, creating a WhatsApp status can be difficult, so we have put together some of the best WhatsApp Statuses."},
    {"name":"sarita" ,"age":25, "doj":{"date":(2020,10,6)}},
    {"name":"nitesh" ,"age":16, "doj":{"date":(2015,11,5)}}
    ]
    return render(request,"newfor.html",{"list":dict})



