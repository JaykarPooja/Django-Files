from django.shortcuts import render

# Create your views here.               #
def index(request):
    # name="yogesh"
    # return render(request,"index.html",{'name1':name})   # name1 is a key => paasing name variable to html page
    dict=[
        {"name":"yogesh" ,"age":25, "doj":"2024-1-1"},
        {"name":"pooja" ,"age":20, "doj":"2020-8-12"},  
        {"name":"neeta" ,"age":17, "doj":"2015-9-15"},
        # {"name":"ritu" ,"age":22, "doj":"date":(2020,10,6),"about":"Social media has become an essential part of day-to-day life in this technology-friendly era. Updating a WhatsApp Status gives your contacts a small glimpse into your life. However, creating a WhatsApp status can be difficult, so we have put together some of the best WhatsApp Statuses."}
        ]
    return render(request,"index.html",{"list":dict})

def about(request):
    student={
        'name': "Yogesh",
        'age': 25,
        'course': 'Fullstack'
    }
    dict=[
        {"name":"yogesh" ,"age":25},
        {"name":"pooja" ,"age":25}
        ]
    return render(request,"about.html",{"list":dict})    # student = dictionary paasing to html page

def contact(request):
    return render(request,"contact.html")

def sum(request):
    try:
        x=int(request.Get.get('first',0))
        y=int(request.Get.get('second',0))
        z = x+y
        return render(request,"sum.html",{'addition':z})
    except:
        return render(request,"sum.html",{'addition':0})


