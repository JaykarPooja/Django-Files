from django.contrib import admin
from .models import Employee

# Register your models here.

class EmployeeAdmin(admin.ModelAdmin):
    list_display = ['id','name','email','gender','contact','dept','salary','image']

admin.site.register(Employee,EmployeeAdmin)


#commands to make admin user &password
# python manage.py createsuperuser    enter
# .... username: leave blank           & enter
# enter enter password:enter password
# confirm password: again enter password
# then admin site will open

