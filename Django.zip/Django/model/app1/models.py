from django.db import models

# Create your models here.
class Employee(models.Model):
    gen = (('male','Male'),
           ('female','Female'),
           ('others','Others'))
    name = models.CharField(max_length=50)
    email = models.EmailField(max_length=254)
    contact = models.BigIntegerField(max_length=10)
    dept = models.CharField(max_length=50) 
    gender = models.CharField(max_length=50, choices=gen, null=True)
    salary=models.DecimalField(max_digits=7, decimal_places=2, null=True)
    image=models.ImageField(upload_to="image", null=True)