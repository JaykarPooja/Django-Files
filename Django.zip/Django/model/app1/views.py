from django.shortcuts import render
from django.shortcuts import redirect
from .models import Employee
# Create your views here.
def index(request):                                #read
    data = Employee.objects.all()
    print(data)
    return render(request,'index.html',{'data':data})

def add_data(request):                              #create
    if request.method == 'POST':
        try:
            name = request.POST['name']
            email = request.POST['email']
            contact = request.POST['contact']
            salary = request.POST['salary']
            gender = request.POST['gender']
            department = request.POST['department']          #name from add_form html files
            image = request.FILES['image']
            print(name)
            data= Employee.objects.create(name=name, email=email,dept=department,contact=contact,salary=salary,gender=gender,image=image)
            data.save()
            return redirect('index')
        except:
            return render(request,'addform.html')
    else:
        return render(request,'addform.html')

def delete_data(request,email):
    data=Employee.objects.filter(email=email)
    data.delete()
    return redirect('index')

def update_data(request,email):
    data=Employee.objects.get(email=email)         #.get for data and .filter for queryset
    if request.method == 'POST':
        try:
            name = request.POST['name']
            email = request.POST['email']
            contact = request.POST['contact']
            salary = request.POST['salary']
            gender = request.POST['gender']
            department = request.POST['department']
            data = Employee.objects.filter(email=email)       # filter queryselect method => automatically saves data no need to data.save()
            data.update(name=name,email=email,dept=department,contact=contact,salary=salary,gender=gender)
            return redirect('index')
        except:
            return render(request,'updateform.html')    
    return render(request,"updateform.html",{'data':data})
