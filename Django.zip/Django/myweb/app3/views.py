from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

# def sum(request):
#     num1=10
#     num2=20
#     result = num1+num2
#     return HttpResponse(f"sum is {result}" )

def home(request):
    return HttpResponse("App3 home page")

def about(request):
    return HttpResponse("App3 about page")
