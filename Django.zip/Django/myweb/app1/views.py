from django.shortcuts import render
from django.http import HttpResponse  #

# Create your views here.

# def home(request):              # request same like self
#     return HttpResponse("<h1> Hello World! </h1>")   #

# def about(request):              # request same like self
#     return HttpResponse("This is about page") 

def home(request):
    return HttpResponse("App1 home page")

def about(request):
    return HttpResponse("App1 about page")